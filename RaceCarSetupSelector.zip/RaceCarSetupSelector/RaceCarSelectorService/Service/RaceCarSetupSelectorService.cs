﻿using RaceCarSelectorService.Contract;
using RaceCarSelectorService.Model;
using RaceCarSelectorService.BusinessLayer;

namespace RaceCarSelectorService.Service
{
    /// <summary>
    /// Service containing methods EvaluateRaceCar and EvaluateAndSortRaceCar
    /// </summary>
    public class RaceCarSetupSelectorService : ICarSelectorService
    {   
        /// <summary>
        /// Method that evaluates race car for given car configuration and against given race track
        /// </summary>
        /// <param name="raceTrack"></param>
        /// <param name="carConfig"></param>
        /// <returns></returns>
        public RaceCarEvaluation EvaluateRaceCar(RaceTrack raceTrack, CarConfiguration carConfig)
        {
            RaceCarEvaluation raceCarEvaluation = new RaceCarEvaluation(raceTrack, carConfig);

            //Calculate total pit stops required.
            int NumberOflapsWithFullFuelCapacity = (int)(carConfig.FuelCapacity / carConfig.AverageFuelConsumptionPerLap);
            int RequiredTotalPitStops = raceTrack.NumberOfLapsToComplete / NumberOflapsWithFullFuelCapacity;

            //Calculate total time required to complete race
            int totalTimeToCompleteGivenLaps = (int) (carConfig.TimeToCompleteLap * raceTrack.NumberOfLapsToComplete);
            int totalTimeRequiredAtPitStops = RequiredTotalPitStops * raceTrack.TimeItTakesToMakePitstop;
            raceCarEvaluation.FullRaceCompletionTime = totalTimeToCompleteGivenLaps + totalTimeRequiredAtPitStops;
            
            return raceCarEvaluation;
        }




        /// <summary>
        /// Method that evaluates race car for given array of car configuration and against given race track
        /// Use quick sort to sort the array of race car evaluation
        /// </summary>
        /// <param name="raceTrack"></param>
        /// <param name="carConfig"></param>
        /// <returns></returns>
        public RaceCarEvaluation[] EvaluateAndSortRaceCar(RaceTrack raceTrack, CarConfiguration[] carConfig)
        {
            //Creating array of type RaceCarEvaluation and length equal to number of car configurations passed
            RaceCarEvaluation[] raceCarEvaluation = new RaceCarEvaluation[carConfig.Length];

            // Calling EvaluateRaceCar function to evaluate race car for given car configuration and against given race track
            for (int i = 0; i < carConfig.Length; i++)
            {
                raceCarEvaluation[i] = this.EvaluateRaceCar(raceTrack, carConfig[i]);
            }

            //Calling Quick Sort algo to sort the raceCarEvaluation array
            QuickSortAlgo<RaceCarEvaluation> raceCarEvaluationSort = new QuickSortAlgo<RaceCarEvaluation>(raceCarEvaluation);
            raceCarEvaluationSort.Sort();
            
            return raceCarEvaluationSort.Output;
        }

    }
}