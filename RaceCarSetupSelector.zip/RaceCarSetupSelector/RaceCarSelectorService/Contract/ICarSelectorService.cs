﻿
using RaceCarSelectorService.Model;

namespace RaceCarSelectorService.Contract
{
    public interface ICarSelectorService
    {
        /// <summary>
        /// Evaluate completion time for a single car configuration against a given race track
        /// </summary>
        /// <param name="raceTrack"></param>
        /// <param name="carConfig"></param>
        /// <returns></returns>
        RaceCarEvaluation EvaluateRaceCar(RaceTrack raceTrack, CarConfiguration carConfig);

        /// <summary>
        /// Evaluate completion times for a list of car configurations and sort evaluations from fastest to slowest 
        /// against a given race track
        /// </summary>
        /// <param name="raceTrack"></param>
        /// <param name="carConfig"></param>
        /// <returns></returns>
        RaceCarEvaluation[] EvaluateAndSortRaceCar(RaceTrack raceTrack, CarConfiguration[] carConfig);
    }
}