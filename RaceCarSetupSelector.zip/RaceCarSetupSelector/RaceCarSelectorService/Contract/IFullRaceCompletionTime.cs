﻿
namespace RaceCarSelectorService.Contract
{
    public interface IFullRaceCompletionTime
    {
        /// <summary>
        /// Completion time property is used to rank a given set of car configurations for a particular, 
        /// given, race track, based on the full race completion time.
        /// </summary>
        double FullRaceCompletionTime { get; set; }
    }
}