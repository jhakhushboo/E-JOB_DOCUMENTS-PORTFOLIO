﻿namespace RaceCarSelectorService.Model
{
    public class CarConfiguration
    {
        private double _fuelCapacity;
        private double _timeToCompleteLap;
        private double _averageFuelConsumptionPerLap;

        /// <summary>
        /// Measured in litres
        /// </summary>
        public double FuelCapacity { get => _fuelCapacity; set => _fuelCapacity = value; }
        /// <summary>
        /// Measured in seconds
        /// </summary>
        public double TimeToCompleteLap { get => _timeToCompleteLap; set => _timeToCompleteLap = value; }
        /// <summary>
        /// Measured in litres
        /// </summary>
        public double AverageFuelConsumptionPerLap { get => _averageFuelConsumptionPerLap; set => _averageFuelConsumptionPerLap = value; }
    }
}