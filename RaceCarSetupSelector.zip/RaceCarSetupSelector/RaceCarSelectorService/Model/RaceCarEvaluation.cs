﻿using RaceCarSelectorService.Contract;
namespace RaceCarSelectorService.Model
{
    public class RaceCarEvaluation : IFullRaceCompletionTime
    {
        /// <summary>
        /// Race track property
        /// </summary>
        public RaceTrack RaceTrack { get; set; }
        
        /// <summary>
        /// Car configuration property
        /// </summary>
        public CarConfiguration CarConfiguration { get; set; }
        
        /// <summary>
        /// Completion time property
        /// </summary>
        public double FullRaceCompletionTime { get; set; }

        /// <summary>
        /// Constructor used to initialize member properties
        /// </summary>
        /// <param name="raceTrack"></param>
        /// <param name="carConfiguration"></param>
        public RaceCarEvaluation(RaceTrack raceTrack, CarConfiguration carConfiguration)
        {
            this.RaceTrack = raceTrack;
            this.CarConfiguration = carConfiguration;
        }
    }
}