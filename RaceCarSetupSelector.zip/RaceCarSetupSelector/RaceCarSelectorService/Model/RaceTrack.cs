﻿namespace RaceCarSelectorService.Model
{
    public class RaceTrack
    {
        private double _lapDistance;
        private int _numberOfLapsToComplete;
        private int _timeItTakesToMakePitstop;

        /// <summary>
        /// Measured in kilometers
        /// </summary>
        public double LapDistance { get => _lapDistance; set => _lapDistance = value; }
        
        /// <summary>
        /// Integer value
        /// </summary>
        public int NumberOfLapsToComplete { get => _numberOfLapsToComplete; set => _numberOfLapsToComplete = value; }
        
        /// <summary>
        /// Measured in seconds
        /// </summary>
        public int TimeItTakesToMakePitstop { get => _timeItTakesToMakePitstop; set => _timeItTakesToMakePitstop = value; }
    }
}