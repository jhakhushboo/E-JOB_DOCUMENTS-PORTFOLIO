﻿using RaceCarSelectorService.Model;
using System;

namespace RaceCarSelectorUnitTest.Utils
{
    /// <summary>
    /// This class is used to generate random car configurations
    /// </summary>
    class CarConfigurationGenerator
    {
        public CarConfiguration[] GenerateCarConfigurations(int totalCarsConfigToGenerate)
        {
            Random random = new Random();
            CarConfiguration[] carConfigurations = new CarConfiguration[totalCarsConfigToGenerate];
            for (int i = 0; i < totalCarsConfigToGenerate; i++)
            {
                CarConfiguration carConfiguration = new CarConfiguration();
                carConfiguration.FuelCapacity = random.NextDouble() * 50 + 50; // Total fuel capacity in litres that the car can hold, range [50 - 100]
                carConfiguration.TimeToCompleteLap = random.NextDouble() * 250 + 250; ; // Time in Seconds to complete lap [250 - 500]
                carConfiguration.AverageFuelConsumptionPerLap = random.NextDouble() * 2 + 2; // Average fuel consumption in litres per lap [2 - 4]
                carConfigurations[i] = carConfiguration;
            }
            return carConfigurations;
        }
    }
}
