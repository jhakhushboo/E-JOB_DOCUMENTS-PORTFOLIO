﻿using RaceCarSelectorService.Model;
using RaceCarSelectorService.Service;
using RaceCarSelectorUnitTest.Utils;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace RaceCarSelectorUnitTest
{
    [TestClass]
    public class RaceCarSelectorServiceUnitTest
    {
        private RaceTrack _raceTrack;

        [TestInitialize]
        public void RaceTrackSetUp()
        {
            _raceTrack = new RaceTrack
            {
                LapDistance = 4, //kilometers
                NumberOfLapsToComplete = 150, //integer value
                TimeItTakesToMakePitstop = 30 //seconds
            };
        }

        [TestMethod]
        public void EvaluateCar_SingleTrack()
        {
            var carConfig = new CarConfiguration();
            carConfig.AverageFuelConsumptionPerLap = 3; // Avg fule consumption per lap in litres
            carConfig.FuelCapacity = 90; // Total litres of fuel that the car can hold
            carConfig.TimeToCompleteLap = 400; // Seconds to complete lap

            var carSelectorService = new RaceCarSetupSelectorService();
            RaceCarEvaluation evaluateRaceCar = carSelectorService.EvaluateRaceCar(_raceTrack, carConfig);

            Assert.AreEqual(60150, evaluateRaceCar.FullRaceCompletionTime);
        }

        [TestMethod]
        public void EvaluateMultipleCars_SingleTrack()
        {
            var carConfigGenerator = new CarConfigurationGenerator();
            CarConfiguration[] carConfigs = carConfigGenerator.GenerateCarConfigurations(50);

            var raceCarSelectorService = new RaceCarSetupSelectorService();
            RaceCarEvaluation[] evaluateMultipleRaceCars = raceCarSelectorService.EvaluateAndSortRaceCar(_raceTrack, carConfigs);

            for (int i = 0; i < evaluateMultipleRaceCars.Length; i++)
            {
                if (i > 0)
                {
                    Assert.IsTrue(evaluateMultipleRaceCars[i].FullRaceCompletionTime >= evaluateMultipleRaceCars[i-1].FullRaceCompletionTime);
                }
            }
        }

        [TestMethod]
        [ExpectedException(typeof(NullReferenceException))]
        public void ThrowNullReferenceException_CarConfiguration_Null_InArray()
        {
            var carGenerator = new CarConfigurationGenerator();
            CarConfiguration[] carConfig = carGenerator.GenerateCarConfigurations(100);

            carConfig[50] = null;

            var raceCarSelectorService = new RaceCarSetupSelectorService();
            raceCarSelectorService.EvaluateAndSortRaceCar(_raceTrack, carConfig);
        }


        [TestMethod]
        public void Zero_RaceTrack_CarValues_Handled_NoExceptionIsThrown()
        {
            var raceTrack = new RaceTrack { LapDistance = 0, NumberOfLapsToComplete = 0, TimeItTakesToMakePitstop = 0 };

            var carConfig = new CarConfiguration();
            carConfig.FuelCapacity = 0;
            carConfig.TimeToCompleteLap = 0;
            carConfig.AverageFuelConsumptionPerLap = 0;

            var raceCarSelectorService = new RaceCarSetupSelectorService();
            RaceCarEvaluation raceCarEvaluation = raceCarSelectorService.EvaluateRaceCar(raceTrack, carConfig);
            Assert.IsNotNull(raceCarEvaluation);
        }


        [TestMethod]
        public void Zero_CarValues_Handled_NoExceptionIsThrown()
        {
            var carConfig = new CarConfiguration();
            carConfig.FuelCapacity = 0;
            carConfig.TimeToCompleteLap = 0;
            carConfig.AverageFuelConsumptionPerLap = 0;

            var carEvaluatorService = new RaceCarSetupSelectorService();
            carEvaluatorService.EvaluateRaceCar(_raceTrack, carConfig);
        }
        

        [TestMethod]
        public void Zero_TrackValues_Handled_NoExceptionIsThrown()
        {
            var raceTrack = new RaceTrack { LapDistance = 0, NumberOfLapsToComplete = 0, TimeItTakesToMakePitstop = 0 };

            var carConfig = new CarConfiguration();
            carConfig.FuelCapacity = 200;
            carConfig.TimeToCompleteLap = 300;
            carConfig.AverageFuelConsumptionPerLap = 6.852;

            var raceCarSelectorService = new RaceCarSetupSelectorService();
            RaceCarEvaluation raceCarEvaluation = raceCarSelectorService.EvaluateRaceCar(raceTrack, carConfig);
            Assert.IsNotNull(raceCarEvaluation);
        }
    }
}
