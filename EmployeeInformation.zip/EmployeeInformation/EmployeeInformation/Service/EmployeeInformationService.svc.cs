﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using EmployeeInformation.BusinessLayer;
using EmployeeInformation.Model;


namespace EmployeeInformation.Service
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "EmployeeInformationService" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select EmployeeInformationService.svc or EmployeeInformationService.svc.cs at the Solution Explorer and start debugging.
    public class EmployeeInformationService : IEmployeeInformationService
    {
        private readonly IEmployeeInformationBl _objBl;

        public EmployeeInformationService()
        {
            _objBl = new EmployeeInformationBl();
        }

        public Model.EmployeeInformation GetEmployeeInformationById(int id)
        {
            Model.EmployeeInformation empObj = _objBl.GetEmployeeInformationByIdBl(id);
            return empObj;
        }

        public void SaveEmployeeInformationById(Model.EmployeeInformation empObj)
        {
            _objBl.SaveEmployeeInformationByIdBl(empObj);
        }
    }
}
