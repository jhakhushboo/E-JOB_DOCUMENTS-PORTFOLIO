﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel.Configuration;
using System.Web;

namespace EmployeeInformation.Model
{
    [DataContract]
    public class EmployeeInformation
    {
        [DataMember]
        [Key]
        [Required]
        public int Id { get; set; }

        [DataMember]
        [Required]
        public string FirstName { get; set; }

        [DataMember]
        [Required]
        public string LastName { get; set; }

        [DataMember]
        [Required]
        public string FullName { get; set; }

        [DataMember]
        [Required]
        public string Gender { get; set; }

        [DataMember]
        [Required]
        public DateTime DateOfBirth { get; set; }

        [DataMember]
        [Required]
        public int Married { get; set; }

        [DataMember]
        [Required]
        public int EmployeeTypeId { get; set; }

        [DataMember]
        public int AnnualSalary { get; set; }

        [DataMember]
        public int HourlyPay { get; set; }

        [DataMember]
        public int HoursWorked { get; set; }
    }
}