﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace EmployeeInformation.Model
{
    public class EmployeeInformationContext : DbContext
    {
        public DbSet<EmployeeInformation> Employee { get; set; }
        public EmployeeInformationContext():base("entityDB")
        { }
    }
}