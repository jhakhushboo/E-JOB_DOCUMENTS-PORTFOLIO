﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using EmployeeInformation.DataAccessLayer;

namespace EmployeeInformation.BusinessLayer
{
    public interface IEmployeeInformationBl
    {
        Model.EmployeeInformation GetEmployeeInformationByIdBl(int id);
        void SaveEmployeeInformationByIdBl(Model.EmployeeInformation empObj);
    }

    public class EmployeeInformationBl : IEmployeeInformationBl
    {
        private readonly IEmployeeInformationDal _objDal;

        public EmployeeInformationBl()
        {
            _objDal = new EmployeeInformationDal();
        }

        public Model.EmployeeInformation GetEmployeeInformationByIdBl(int id)
        {
            Model.EmployeeInformation empObj = _objDal.GetEmployeeInformationByIdDal(id);
            return empObj;
        }

        public void SaveEmployeeInformationByIdBl(Model.EmployeeInformation empObj)
        {
            _objDal.SaveEmployeeInformationByIdDal(empObj);
        }
    }
}