﻿using System;
using System.Linq;
using EmployeeInformation.Model;

namespace EmployeeInformation.DataAccessLayer
{
    public interface IEmployeeInformationDal
    {
        Model.EmployeeInformation GetEmployeeInformationByIdDal(int id);
        void SaveEmployeeInformationByIdDal(Model.EmployeeInformation empObj);
    }
    public class EmployeeInformationDal : IEmployeeInformationDal
    {
        private readonly EmployeeInformationContext _context = new EmployeeInformationContext();

        public Model.EmployeeInformation GetEmployeeInformationByIdDal(int id)
        {
            var empInfo = (from e in _context.Employee
                where e.Id == id
                select e).First();
            return empInfo;
        }

        public void SaveEmployeeInformationByIdDal(Model.EmployeeInformation empObj)
        {
            _context.Employee.Add(empObj);
            _context.SaveChanges();
        }
    }
}