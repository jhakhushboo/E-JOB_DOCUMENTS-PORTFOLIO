﻿using System.Windows;
using EmployeeInformationClient.ViewModel;

namespace EmployeeInformationClient.View
{
    /// <summary>
    /// Interaction logic for EmployeeInformation.xaml
    /// </summary>
    public partial class EmployeeInformation : Window
    {
        public EmployeeInformation()
        {
            InitializeComponent();
            DataContext = new EmployeeInformationVm();
        }
    }
}
