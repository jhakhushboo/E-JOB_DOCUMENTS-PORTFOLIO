﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeInformationClient.Model
{
    public class EmployeeInformation
    {
        public int Id { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string FullName { get; set; }

        public string Gender { get; set; }

        public DateTime DateOfBirth { get; set; }

        public int Married { get; set; }

        public int EmployeeTypeId { get; set; }

        public int AnnualSalary { get; set; }
        
        public int HourlyPay { get; set; }
        
        public int HoursWorked { get; set; }
    }
}
