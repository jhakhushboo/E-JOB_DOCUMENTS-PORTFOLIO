﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;
using EmployeeInformationClient.EmployeeInformationServiceReference;
using EmployeeInformationClient.Helper;
using EmployeeInformation = EmployeeInformationClient.Model.EmployeeInformation;

namespace EmployeeInformationClient.ViewModel
{
    public class EmployeeInformationVm : INotifyPropertyChanged
    {
        //model
        private readonly EmployeeInformation _employee = new EmployeeInformation();

        private readonly EmployeeInformationServiceReference.EmployeeInformationServiceClient _client;
        #region Commands
        public RelayCommand GetEmployeeById { get; set; }
        public RelayCommand SaveEmployeeById { get; set; }

        #endregion


        #region Properties

        public int Id
        {
            get => _employee.Id;
            set
            {
                if (value!= _employee.Id)
                {
                    _employee.Id = value;
                    NotifyPropertyChanged("Id");
                }
            }
        }

        public string FirstName
        {
            get => _employee.FirstName;
            set
            {
                if (value != _employee.FirstName)
                {
                    _employee.FirstName = value;
                    NotifyPropertyChanged("FirstName");
                }
            }
        }
        public string LastName
        {
            get => _employee.LastName;
            set
            {
                if (value != _employee.LastName)
                {
                    _employee.LastName = value;
                    NotifyPropertyChanged("LastName");
                }
            }
        }

        public string FullName
        {
            get => _employee.FullName;
            set
            {
                if (value != _employee.FullName)
                {
                    _employee.FullName = value;
                    NotifyPropertyChanged("FullName");
                }
            }
        }

        public string Gender
        {
            get => _employee.Gender;
            set
            {
                if (value != _employee.Gender)
                {
                    _employee.Gender = value;
                    NotifyPropertyChanged("Gender");
                }
            }
        }

        public DateTime DateOfBirth
        {
            get => _employee.DateOfBirth;
            set
            {
                if (value != _employee.DateOfBirth)
                {
                    _employee.DateOfBirth = value;
                    NotifyPropertyChanged("DateOfBirth");
                }
            }
        }

        private string _married;
        public string Married
        {
            get => _married;

            set
            {
                if (value == null) throw new ArgumentNullException(nameof(value));
                if (_employee.Married == 1)
                {
                    _married = "Married";
                    NotifyPropertyChanged("Married");
                }
                else
                {
                    _married = "UnMarried";
                    NotifyPropertyChanged("Married");
                }
            }
        }

        public bool CheckMarried { get; set; }

        public int EmployeeTypeId
        {
            get => _employee.EmployeeTypeId;
            set
            {
                if (value != _employee.EmployeeTypeId)
                {
                    _employee.EmployeeTypeId = value;
                    NotifyPropertyChanged("EmployeeTypeId");
                }
            }
        }

        public int AnnualSalary
        {
            get => _employee.AnnualSalary;
            set
            {
                if (value != _employee.AnnualSalary)
                {
                    _employee.AnnualSalary = value;
                    NotifyPropertyChanged("AnnualSalary");
                }
            }
        }

        public int HourlyPay
        {
            get => _employee.HourlyPay;
            set
            {
                if (value != _employee.HourlyPay)
                {
                    _employee.HourlyPay = value;
                    NotifyPropertyChanged("HourlyPay");
                }
            }
        }

        public int HoursWorked
        {
            get => _employee.HoursWorked;
            set
            {
                if (value != _employee.HoursWorked)
                {
                    _employee.HoursWorked = value;
                    NotifyPropertyChanged("HoursWorked");
                }
            }
        }

        #endregion

        #region Constructor

        public EmployeeInformationVm()
        {
            _client = new EmployeeInformationServiceClient();
            GetEmployeeById = new RelayCommand(GetEmployeeByIdMethod);
        }
        #endregion

        #region Methods

        private void GetEmployeeByIdMethod(object o)
        {
            var emp = _client.GetEmployeeInformationById(Id);
            FirstName = emp.FirstName;
            LastName = emp.LastName;
            FullName = FirstName + ' ' + LastName;
            Gender = emp.Gender;

            EmployeeTypeId = emp.EmployeeTypeId;
            if (EmployeeTypeId ==1)
            {
                //FullTimeEmployee
                AnnualSalary = emp.AnnualSalary;
            }
            else if (EmployeeTypeId==2)
            {
                //PartTimeEmployee
                HoursWorked = emp.HoursWorked;
                HourlyPay = emp.HourlyPay;
            }

            

            //int value, Type targetType, object parameter, CultureInfo culture
        }

        

        #endregion


        #region Interface Implementation
        public event PropertyChangedEventHandler PropertyChanged;
        // This method is called by the Set accessor of each property.
        // The CallerMemberName attribute that is applied to the optional propertyName
        // parameter causes the property name of the caller to be substituted as an argument.
        private void NotifyPropertyChanged(String propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        
        #endregion

    }
}
