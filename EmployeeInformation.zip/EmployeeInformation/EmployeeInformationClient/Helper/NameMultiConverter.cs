﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;

namespace EmployeeInformationClient.Helper
{
    public class NameMultiConverter : IMultiValueConverter
    {
        public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
        {
            // Conversion logic from Target to Source
            string x = "";
            foreach (object y in values)
            {

                x = x + " " + y.ToString();
            }
            return x;
        }

        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
        {
            // Conversion logic from Source to Target.
            string str = (string)value;
            string[] val = str.Split(' ');

            return val;

        }
    }
}
